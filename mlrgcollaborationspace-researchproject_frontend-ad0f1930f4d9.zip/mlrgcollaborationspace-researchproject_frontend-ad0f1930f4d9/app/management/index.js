'use strict';

module.exports = angular.module('mlrg.management', []);
require('./account-management.ctrl');
'use strict';

module.exports = angular.module('mlrg.bibcreate', []);
require('./bib-create.ctrl');
require('./bib-add/bib-add.ctrl');
require('./bib-upload/bib-upload.ctrl');
'use strict';

module.exports = angular.module('mlrg.directives', []);

require('./directives');
'use strict';

module.exports = angular.module('mlrg.userworkspace', []);
require('./user-workspace.ctrl');
require('./view-shared-with/view-shared-with-modal.ctrl');
require('./share/share-list-modal.ctrl');
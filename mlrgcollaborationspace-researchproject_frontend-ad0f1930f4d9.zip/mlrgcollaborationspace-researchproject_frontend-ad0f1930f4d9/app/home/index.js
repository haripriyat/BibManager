'use strict';

module.exports = angular.module('mlrg.home', []);
require('./home.ctrl');
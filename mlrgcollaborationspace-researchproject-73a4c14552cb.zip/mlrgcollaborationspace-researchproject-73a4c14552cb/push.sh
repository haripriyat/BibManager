git add .
git commit -m "master : minor change"
git push -u origin master

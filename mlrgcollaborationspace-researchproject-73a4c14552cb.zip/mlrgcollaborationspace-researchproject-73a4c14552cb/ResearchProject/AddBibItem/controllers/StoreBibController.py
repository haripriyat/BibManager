import json
from ast import literal_eval

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()

import datetime
from Util.ConnectionMananger import ConnectionManager
from AddBibItem.models import BibStore


def callback(ch, method, properties, body):
    ch.basic_ack(delivery_tag=method.delivery_tag)
    statusUpdationObject = ConnectionManager()
    statusUpdationObject.setupConnection(queue="StatusUpdationQueue")
    data = literal_eval(body)
    print data["payload"]
    bibObject = BibStore()

    bibObject.author = data["payload"]["author"]
    bibObject.abstract = data["payload"]["abstract"]
    bibObject.markedEntry = data["payload"]["__markedentry"]
    bibObject.address = data["payload"]["address"]
    bibObject.bookTitle = data["payload"]["booktitle"]
    bibObject.chapter = data["payload"]["chapter"]
    bibObject.comment = data["payload"]["comment"]
    bibObject.crossRef = data["payload"]["crossref"]
    bibObject.doi = data["payload"]["doi"]
    bibObject.edition = data["payload"]["edition"]
    bibObject.editor = data["payload"]["editor"]
    bibObject.file = data["payload"]["file"]
    bibObject.howPublished = data["payload"]["howpublished"]
    bibObject.institution = data["payload"]["institution"]
    bibObject.journal = data["payload"]["journal"]
    bibObject.keywords = data["payload"]["keywords"]
    bibObject.month = data["payload"]["month"]
    bibObject.note = data["payload"]["note"]
    bibObject.number = data["payload"]["number"]
    bibObject.organization = data["payload"]["organization"]
    bibObject.owner = data["payload"]["owner"]
    bibObject.pages = data["payload"]["pages"]
    bibObject.publisher = data["payload"]["publisher"]
    bibObject.school = data["payload"]["school"]
    bibObject.series = data["payload"]["series"]
    bibObject.timeStamp = data["payload"]["timestamp"]
    bibObject.title = data["payload"]["title"]
    bibObject.type = data["metadata"]["type"]
    bibObject.url = data["payload"]["url"]
    bibObject.volume = data["payload"]["volume"]
    bibObject.year = data["payload"]["year"]

    bibObject.save()
    statusUpdationObject.send("{'status':'3'}")
    print(" [StoreBib] Received %r" % body)


def storeBib():
    storeBibHandlerObject = ConnectionManager()
    storeBibHandlerObject.setupConnection(queue="StoreBibQueue")
    storeBibHandlerObject.receive(callback=callback)


if __name__ == "__main__":
    storeBib()

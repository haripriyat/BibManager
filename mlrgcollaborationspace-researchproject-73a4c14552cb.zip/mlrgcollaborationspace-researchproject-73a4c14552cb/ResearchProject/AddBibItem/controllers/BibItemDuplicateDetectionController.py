from Util.ConnectionMananger import ConnectionManager


def callback(ch, method, properties, body):
    ch.basic_ack(delivery_tag=method.delivery_tag)
    storeBibHandlerObject = ConnectionManager()
    statusUpdationObject = ConnectionManager()

    storeBibHandlerObject.setupConnection(queue="StoreBibQueue")
    statusUpdationObject.setupConnection(queue="StatusUpdationQueue")

    storeBibHandlerObject.send(data=body)
    statusUpdationObject.send("{'status':'2'}")
    print(" [Duplicate Detection] Received %r" % body)


def DuplicateDetector():
    duplicateDetectionHandlerObject = ConnectionManager()
    duplicateDetectionHandlerObject.setupConnection(queue="DuplicateDetectionQueue")
    duplicateDetectionHandlerObject.receive(callback=callback)



if __name__ == "__main__":
    DuplicateDetector()

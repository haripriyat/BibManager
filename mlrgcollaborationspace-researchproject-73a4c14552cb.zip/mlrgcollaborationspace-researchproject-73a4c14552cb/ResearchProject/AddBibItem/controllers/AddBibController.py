from Util.ConnectionMananger import ConnectionManager
import uuid

def addBib(msg):
    dupilcateDetectionObject = ConnectionManager()
    statusUpdationObject = ConnectionManager()

    dupilcateDetectionObject.setupConnection(queue="DuplicateDetectionQueue")
    statusUpdationObject.setupConnection(queue="StatusUpdationQueue")

    dupilcateDetectionObject.send(data=msg)
    statusUpdationObject.send("{'status':'1'}")

import json
from ast import literal_eval

# from prettyprint import pp
from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.views.generic import View

from AddBibItem.controllers.AddBibController import addBib


class AddBibView(View):

    def post(self, request):
        requestData = {
            "metadata": {
                "type": "inproceedings",
                "operation" : "add"
             },

            "payload": {
                "author": "E. Linstead and R. Burns and D. Nguyen and D. Tyler",
                "abstract": "",
                "__markedentry": "",
                "address": "",
                "booktitle": "2016 38th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (EMBC)",
                "chapter": "",
                "comment": "",
                "crossref": "",
                "doi": "10.1109/EMBC.2016.7591249",
                "edition": "",
                "editor": "",
                "file": "",
                "howpublished": "",
                "institution": "",
                "journal": "",
                "keyword": "Autism;Data mining;Feeds;Mobile communication;Schedules;Smart phones",
                "month": "",
                "note": "",
                "number": "",
                "organization": "",
                "owner": "",
                "pages": "7591249",
                "publisher": "",
                "school": "",
                "series": "",
                "timestamp": "",
                "title": "AMP: A platform for managing and mining data in the treatment of Autism Spectrum Disorder",
                "type": "",
                "url": "",
                "volume": "",
                "year": "2016"
            }
        }
        data = request.body
        addBib(data)
        return HttpResponse("Adding item now")

    def get(self, request):
        return render(request, 'test.html')

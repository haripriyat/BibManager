from __future__ import unicode_literals

from django.db import models

# Create your models here.
from django.db import models


class BibStore(models.Model):
    class Meta:
        app_label = 'AddBibItem'
    type          = models.TextField()
    author        = models.TextField()
    abstract      = models.TextField()
    markedEntry   = models.TextField()
    address       = models.TextField()
    bookTitle     = models.TextField()
    chapter       = models.TextField()
    comment       = models.TextField()
    crossRef      = models.TextField()
    doi           = models.TextField()
    edition       = models.TextField()
    editor        = models.TextField()
    file          = models.TextField()
    howPublished  = models.TextField()
    institution   = models.TextField()
    journal       = models.TextField()
    keywords      = models.TextField()
    month         = models.TextField()
    note          = models.TextField()
    number        = models.TextField()
    organization  = models.TextField()
    owner         = models.TextField()
    pages         = models.TextField()
    publisher     = models.TextField()
    school        = models.TextField()
    series        = models.TextField()
    timeStamp     = models.TextField()
    title         = models.TextField()
    type          = models.TextField()
    url           = models.TextField()
    volume        = models.TextField()
    year          = models.TextField()

from __future__ import unicode_literals

from django.apps import AppConfig


class AddbibitemConfig(AppConfig):
    name = 'AddBibItem'

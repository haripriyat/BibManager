from Util.ConnectionMananger import ConnectionManager


def callback(ch, method, properties, body):
    ch.basic_ack(delivery_tag=method.delivery_tag)
    # Updating the status into the model
    print(" [Status] Received %r" % body)


def statusCheck():
    statusCheckObject = ConnectionManager()
    statusCheckObject.setupConnection(queue="StatusUpdationQueue")
    statusCheckObject.receive(callback=callback)



if __name__ == "__main__":
    statusCheck()
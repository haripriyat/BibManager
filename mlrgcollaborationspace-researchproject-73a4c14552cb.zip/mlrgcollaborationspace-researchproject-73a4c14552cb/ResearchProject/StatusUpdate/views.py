from django.http.response import HttpResponse
from django.views.generic import View


class StatusUpdate(View):
    def get(self, request):
        return HttpResponse("viewed")
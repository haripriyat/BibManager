import json
from ast import literal_eval

# from prettyprint import pp
from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.views.generic import View

from AddBibItem.controllers.AddBibController import addBib


class HomeView(View):

    def get(self, request):
        return render(request, 'index.html')

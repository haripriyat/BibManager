import pika


class ConnectionManager:
    def __init__(self):
        pass

    def setupConnection(self, queue, host='localhost'):
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(
            host=host))
        self.channel = self.connection.channel()
        self.channel.queue_declare(queue=queue, durable=True)
        self.queue = queue

    def send(self, data):
        # type: (object) -> object
        self.channel.basic_publish(exchange='',
                                   routing_key=self.queue,
                                   body=data,
                                   properties=pika.BasicProperties(
                                       delivery_mode=2,  # make message persistent
                                   ))
        print(" [x] Sent %r" % data)
        self.closeConnection()

    def receive(self, callback):
        # type: (object) -> object
        print(' [*] Waiting for messages. To exit press CTRL+C')

        self.channel.basic_qos(prefetch_count=1)
        self.channel.basic_consume(callback,
                                   queue=self.queue)
        self.channel.start_consuming()

    def closeConnection(self):
        self.connection.close()

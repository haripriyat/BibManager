import os, sys , platform


def setupEnviroment():
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    if platform.system() == "Windows":
        # For Windows based Machines
        return get_wsgi_application()
    elif platform.system() == "Linux":
        # For Linux based Machines
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ResearchProject.localsettings")
        return get_wsgi_application()
